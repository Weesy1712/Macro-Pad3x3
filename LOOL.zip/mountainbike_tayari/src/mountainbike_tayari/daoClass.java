package mountainbike_tayari;

public class daoClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
